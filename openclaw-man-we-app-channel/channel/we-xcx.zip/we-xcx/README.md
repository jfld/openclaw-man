# WE XCX Channel Plugin for OpenClaw

This is a standalone OpenClaw channel plugin for WE XCX integration.

## Project Structure

- `index.ts`: Main plugin source code.
- `openclaw.plugin.json`: Plugin metadata and configuration schema.
- `package.json`: Dependencies and scripts.
- `dist/`: Compiled output.
- `channel/`: Packaged plugin output (zip file).

## Development

1. Install dependencies:
   ```bash
   npm install
   ```

2. Build the plugin:
   ```bash
   npm run build
   ```

3. Run tests:
   ```bash
   npm test
   ```

4. Package for distribution:
   ```bash
   npm run package
   ```
   The output file will be at `channel/we-xcx.zip`.

## Configuration

The plugin uses WebSocket to connect to the WE XCX service.
Configure `apiKey`, `apiEndpoint`, and `useTls` in the OpenClaw configuration.
