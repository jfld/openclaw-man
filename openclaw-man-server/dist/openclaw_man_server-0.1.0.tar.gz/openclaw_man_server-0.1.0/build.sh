#!/bin/bash
DOCKER_BUILDKIT=1 docker build -t openclaw-man-server:0.1.0 .
